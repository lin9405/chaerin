import 'package:flutter/material.dart';

class MainPageState extends State<MainPage> {
  var title = '';
  Drawer _buildDrawer(context){
    return new Drawer(
      child: new ListView(
        children: <Widget>[
          new DrawerHeader(
            child: new Container(
              child: new Column(
                children: <Widget>[
                  new Text('park chaerin',
                  style: new TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold
                  ),),
                  new Text('dafadfadfadsa',
                  style: new TextStyle(
                    color: Colors.black,

                  ),
                  ),
                ],
                )
            )
          )

    ],
            ),
          
    );

  }

  @override
  Widget build(BuildContext context){
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("drawer in flutter"),
      ),
      body: new Center(
        child: new Text(this.title, style: new TextStyle(fontSize: 25.0),),
        ),
      
        drawer: _buildDrawer(context),
     
  );
  }

}

class MainPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new MainPageState();

  }
}