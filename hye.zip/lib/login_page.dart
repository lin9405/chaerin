import 'package:flutter/material.dart';
import 'register_page.dart';
import 'findPassword.dart';
import 'findID.dart';
import 'menu.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:async';



class LoginPage extends StatefulWidget{
  static String tag ='login-page';
  _LoginPageState createState() => new _LoginPageState();
}

/*class CircleClipper extends CustomClipper<Rect>{
  Rect getClip(Size size){
    return Rect.fromCircle(
      center: Offset(size.width/2, size.height/2), 
      radius: min(size.width, size.height)/2
    );
    
  }
}*/

class _LoginPageState extends State<LoginPage>{
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = new GoogleSignIn();
 // googleSignIn = new GoogleSignIn();

  Future<FirebaseUser> _signIn() async{
    GoogleSignInAccount googleSignInAccount = await googleSignIn.signIn();
    GoogleSignInAuthentication gSA = await googleSignInAccount.authentication;

    FirebaseUser user = await _auth.signInWithGoogle(
      idToken: gSA.idToken, accessToken: gSA.accessToken);
      print('User Name: ${user.displayName}');
       Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => menuPage()));
      return user;
      }
  void _signOut(){
    googleSignIn.signOut();
    print('User signed out');
  }

  /*final formKey= new GlobalKey<FormState>();
  String _email;
  String _password;

  bool validateAndSave()
  {
    final form = formKey.currentState;
    //form.save();
    if(form.validate()){
      form.save();//onSave에 해당하는 거 실행.
      form.reset();//입력 칸 비우기.
      //print('Form is valid. id:$_id, password:$_password');
      return true;
    }//else{
      //print('Form is invalid. id:$_id, password:$_password');
    //}
    return false;
  }

  void validateAndSubmit() async{ 
    if(validateAndSave()){
      try{
         FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password);
         print('Sign in: ${user.uid}');
        //if(_formType==FormType.login){
      //FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(ID: _id,Password: _password);     
      //print('Signed in: ${user.uid}');
      }//else{
      //FirebaseUser user = await FirebaseAuth.instance.createUserWithAndPassword(ID: _id,Password: _password);
      //print('Signed in: ${user.uid}');
      //}

      //}
      catch(e)
      {
        print('Error: $e');
      }
    }
  }*/

  Widget build(BuildContext context){
 
       return new Scaffold(
        backgroundColor: Colors.white,
        body: Center(
            child: new Form(
              //key: formKey,
              child: new ListView(
                shrinkWrap: true,//Scrollable
                padding: EdgeInsets.only(left: 24.0, right: 24.0),
                children: buildInputs()
              ),
            )
        )
    );




  /*  return Scaffold(
      backgroundColor: Colors.white,
      body:Center(
        child: ListView(
          shrinkWrap: true,
          padding:EdgeInsets.only(left: 24.0, right: 24.0),
          children: <Widget>[
            logo,
            SizedBox(height: 48.0),
            id,
            SizedBox(height: 8.0),
            password,
            SizedBox(height: 8.0),
            loginButton,
            register,
            forgotLabel1,
            forgotLabel2

          ],
      ),
      ),
    );*/


      
  }

   List<Widget> buildInputs(){

    return[
      SizedBox(height: 48.0),
      new Container(
      child: new ClipOval(
        //clipper: CircleClipper(),
        child: Image.asset('assets/snuppy.jpg'),
      ),

     ), 
     SizedBox(height: 48.0),
   
   
   /*final logo = Container(
      width: 200.0,
      height: 200.0,
      decoration: new BoxDecoration(
        shape: BoxShape.circle,
        image: new DecorationImage(
          fit:  BoxFit.contain,
          image: AssetImage('assets/snuppy.jpg'),
        ),
        
      ),
      );*/
   
   /* final logo = Hero(
      tag:'hp',
      child: Padding(        
        padding: EdgeInsets.all(32.0),
        child: CircleAvatar(
          radius: 72.0,
          backgroundColor: Colors.transparent,
          backgroundImage: AssetImage('assets/happiness.jpg'),
        ),
        ),
    );*/
    
    /*final logo = Hero(
      tag: 'happiness',
      child: CircleAvatar(
        backgroundColor: Colors.transparent,
        radius: 55.0,
        child: Image.asset('assets/happiness.jpg'),
        ),
        );*/

    /*new TextFormField(
      //keyboardType: TextInputType.emailAddress,
      autofocus: false,
      //initialValue: 'alucrd@gamail.com',
      decoration: InputDecoration(
        hintText: 'E-mail',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(32.0)
        ),
      ),
      validator: validateEmail,
      onSaved: (value) =>_email =value,
     ),
     SizedBox(height: 6.0),


     new TextFormField(
      autofocus: false,
      //initialValue: 'some password',
      obscureText: true,
      decoration: InputDecoration(
        hintText: 'Password',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(32.0)
        ),
      ),
      validator: (value) =>value.isEmpty ? 'Password can\'t be enpty':null,
      onSaved: (value) =>_password =value,
     ),
     SizedBox(height: 6.0),*/

     new Padding(
       padding: EdgeInsets.symmetric(vertical: 16.0),
       child: Material(
         borderRadius: BorderRadius.circular(30.0),
         shadowColor: Colors.lightBlueAccent.shade100,
         elevation: 5.0,
         child: MaterialButton(
           minWidth: 200.0,
           height: 42.0,
           onPressed: ()=> _signIn()
            .then((FirebaseUser user) => print(user))
            .catchError((e)=>print(e)),
           //{
             //validateAndSubmit();
             /* Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => menuPage()),*/
           // );
          
          // },
           color: Colors.lightBlueAccent,
           child: Text('Log In',style: TextStyle(color: Colors.white)), 
              ),
       ),
       ),
       SizedBox(height: 6.0),

       new FlatButton(
         child: Text('become a member', style: TextStyle(color: Colors.black45),
         ),
         onPressed:() {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RegisterPage()),
            );
         }
       ),
       SizedBox(height: 6.0),

        new FlatButton(
         child: Text('Forgot id?', style: TextStyle(color: Colors.black45),
         ),
         onPressed: (){
           Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => findIdPage()),
            );
         },
       ),
       SizedBox(height: 6.0),

       new FlatButton(
         child: Text('Forgot password?', style: TextStyle(color: Colors.black45),
         ),
         onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => findPasswordPage()),
            );
         },
       ),
       SizedBox(height: 6.0),
    ];
    }

     String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Not a valid email.';
    else
      return null;
  }
}