library my_prj.globals;
import 'dart:io';


File image;
String globalID;
//GoogleSignIn googleSignIn;
