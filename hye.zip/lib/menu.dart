import 'package:flutter/material.dart';
import 'gloals.dart' as globals;
import 'login_page.dart';


class menuPage extends StatelessWidget {
  Widget build(BuildContext context)
  {

    return new Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.white,
       // title:new Text("data"),
    ),
    drawer: new Drawer(
      child: new ListView(
        children: <Widget>[
          new UserAccountsDrawerHeader(
            accountName: new Text("Lee Myeonghui"),
            accountEmail: new Text("myeonghui@handong.edu"),
            currentAccountPicture: new CircleAvatar(
              backgroundColor: Colors.white,
              //child: new Text("P"),
              child: globals.image == null? new Text('No image'):new Image.file(globals.image),
              
            ),
           otherAccountsPictures: <Widget>[
             new CircleAvatar(
               backgroundColor: Colors.white,
               child: new Text("k"),
             )
           ],
          ),
          new ListTile(
            title: new Text("My Page"),
            trailing: new Icon(Icons.arrow_right),
          ),
          new ListTile(
            title: new Text("Main"),
            trailing: new Icon(Icons.arrow_right,
          )
          ),
           new ListTile(
            title: new Text("Our Posting"),
            trailing: new Icon(Icons.arrow_right),
          ),
          new Divider(),
          /*new ListTile(
            title: new Text("Sign Out"),
            trailing: new Icon(Icons.exit_to_app),
            onPr:{
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RegisterPage()),
            )
         },
    
          ),*/
        new FlatButton(
         child: Text('Forgot id?', style: TextStyle(color: Colors.black45),
         ),
         onPressed: (){
           Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => LoginPage().),
            );
         },
       ),
          new Divider(),
          new ListTile(
            title: new Text("Close"),
            trailing: new Icon(Icons.close),
            onTap: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    ),
    );
  }
}
