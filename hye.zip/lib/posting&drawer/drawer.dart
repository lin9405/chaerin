import 'package:flutter/material.dart';
import './other_page.dart';

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _HomePageState();
  }
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        title: new Text('My Drawer App'),
        backgroundColor: Colors.redAccent,
      ),
      body: new Center(
        child: new Text(
          'HomePage',
          style: new TextStyle(fontSize: 35.0),
        ),
      ),
      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              currentAccountPicture: new GestureDetector(
                onTap: () => print('This is the current user'),
                child: new CircleAvatar(
                  backgroundImage: new NetworkImage(
                      "https://s-i.huffpost.com/gen/3920294/thumbs/o-ZEBRA-570.jpg?1"),
                ),
              ),
              
              accountName: Text('Lee Hyunji'), // 여기다가 유저 네임 적으면 될듯!!!
              accountEmail:
                  Text('leehyunji0715@gmail.com'), //유저 이메일 적으면 될듯! - 파이어베이스
              decoration: new BoxDecoration(
                  image: new DecorationImage(
                      fit: BoxFit.fill,
                      image: new NetworkImage(
                          "http://colorate.azurewebsites.net/SwatchColor/427314"))),
            ),
            new ListTile(// 메뉴바 List들....
                title: Text('My Posting'),
                leading: new Icon(Icons.person),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          new OtherPage("First Page")));
                }),
            new ListTile(
                title: Text('Our Posting'),
                leading: new Icon(Icons.group),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          new OtherPage("Second Page")));
                }),
            new ListTile(
                title: Text('Invite'),
                leading: new Icon(Icons.favorite),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          new OtherPage("초대 페이지")));
                }),
                new ListTile(
                title: Text('Setting'),
                leading: new Icon(Icons.settings),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          new OtherPage("Setting")));
                }),
            new Divider(),// 경계선 나누기
            new ListTile(
              title: Text('close/logout'),//이 부분을 logout으로 해도 될듯!
              leading: new Icon(Icons.cancel),
              onTap: () => Navigator.of(context).pop(),
            )
          ],
        ),
      ),
    );
  }
}
