import 'package:flutter/material.dart';
import './home_page.dart';

main(){
  runApp(new MaterialApp(
    home: new HomePage(),
  ));
}