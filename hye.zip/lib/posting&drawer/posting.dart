/**
 * youtube : https://www.youtube.com/watch?v=3Cm7WzH3gb8&index=15&list=PLH5_-Jfo8Pl86tXLuFTM6k8UA-vSvDEaO
 */

import 'package:flutter/material.dart';

class Posting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PostingPage(),
    );
  }
}

class PostingPage extends StatefulWidget {
  @override
  _PostingPageState createState() => _PostingPageState();
}

class _PostingPageState extends State<PostingPage>
    with SingleTickerProviderStateMixin {
  TabController _tabController;
  ScrollController _scrollViewController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(vsync: this, length: 2);
    _scrollViewController = ScrollController(initialScrollOffset: 0.0);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollViewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

// ==> 이 부분이 Posting 페이지의 큰 부분을 정하는 부분이다.....
    return Scaffold(
      drawer: new Drawer(),// 여기서 드로워를 추가한다면?? ==> 이 부분은 드로워 부분을 다 완성한 후에 사용하는 것이 좋겠다...


      body: NestedScrollView(
        controller: _scrollViewController,
        headerSliverBuilder: (BuildContext context, bool boxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              title: Text('Posting'), // AppBar 큰 제목
              pinned: true,
              floating: true,
              forceElevated: boxIsScrolled,
              bottom: TabBar(
                tabs: <Widget>[
                  Tab(
                    text: "My Posting",
                    icon: Icon(Icons.person),
                  ),
                  Tab(
                    text: "Our Posing",
                    icon: Icon(Icons.people),
                  )
                ],
                controller: _tabController,
              ),
            )
          ];
        },
        body: TabBarView(
          children: <Widget>[
            PageOne(),
            PageTwo(),
          ],
          controller: _tabController,
        ),
      ),
      // floatingActionButton: FloatingActionButton(
      //   child: Icon(Icons.control_point),
      //   onPressed: () {
      //     _tabController.animateTo(1,
      //         curve: Curves.bounceInOut, duration: Duration(milliseconds: 10));

      //     _scrollViewController
      //         .jumpTo(_scrollViewController.position.maxScrollExtent);
      //   },
      // ), ==> 여.기는 새로운 포스팅 추가하는 부분인데, 나는 필요 없을 것 같다...
    );
  }
}

class PageOne extends StatelessWidget {
  //int a = 1;
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 10, // 포스팅 개수 정함...
      itemExtent: 180.0,// 포스팅 하는 부분 크기 정함..
      itemBuilder: (context, index) => Container(
            padding: EdgeInsets.all(10.0),
            child: Material(
              elevation: 4.0,
              borderRadius: BorderRadius.circular(5.0),
              color: Colors.blue[100],
              child: Center(
                child: Text((index+1).toString()),//포스팅 내용을 정하는 부분
              ),
            ),
          ),
    );
  }
}

class PageTwo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 10,
      itemExtent: 180.0,
      itemBuilder: (context, index) => Container(
            padding: EdgeInsets.all(10.0),
            child: Material(
              elevation: 4.0,
              borderRadius: BorderRadius.circular(5.0),
              color: Colors.blue[100],
              child: Center(
                child: Text((index+1).toString()),
              ),
            ),
          ),
    );
  }
}
